<?php

namespace HotelBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;

use HotelBundle\Entity\User;
use HotelBundle\Entity\UserRole;
use Symfony\Component\HttpFoundation\Response;


class DefaultController extends Controller
{


    /**
     * @Route("/")
     */
    public function indexAction()
    {

        $user = $this->container->get('security.context')->getToken()->getUser();

        if ($this->get('security.authorization_checker')->isGranted('ROLE_ADMIN')) {
            $em = $this->getDoctrine()->getManager();

            echo "truee";
            //return $this->redirect($this->generateUrl('home'));
            return $this->render('HotelBundle:Default:index.html.twig');


        }
    }

    /**
     * @Route("/home", name="home")
     */
    public function homeAction()
    {


         return $this->render('HotelBundle:Default:index.html.twig');

//            return $this->redirect($this->generateUrl('main_layout', array('cid' => 3)));
//            return $this->render('HotelBundle:Default:index.html.twig');

    }
}
