<?php

namespace HotelBundle\Controller;

use Doctrine\Common\Collections\ArrayCollection;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Template;

class PagesController extends Controller
{
    /**
     * @Route("/rooms", name="rooms")
     */
    public function roomAction()
    {

        $em = $this->getDoctrine()->getManager();
        $all_rooms = $em->getRepository('HotelBundle:Room')->findBy(array(), array('code'=>'ASC'));

        return $this->render('HotelBundle:Display:rooms.html.twig', array('rooms'=>$all_rooms));

    }

//    /**
//     * @Route("/clients", name="clients")
//     */
//    public function clientAction()
//    {
//
//        $em = $this->getDoctrine()->getManager();
//        $all_clients = $em->getRepository('HotelBundle:Room')->findAll();
//
//        return $this->render('HotelBundle:Display:clients.html.twig', array('rooms'=>$all_clients));
//
//    }

    /**
     * @Route("/products", name="products")
     */
    public function productAction()
    {

        $em = $this->getDoctrine()->getManager();
        $all_products = $em->getRepository('HotelBundle:Product')->findBy(array(), array('name'=>'ASC'));

        return $this->render('HotelBundle:Display:products.html.twig', array('products'=>$all_products));

    }


    /**
     * @Route("/insertproduct", name="insertproduct")
     */
    public function insertproductAction()
    {
        $em = $this->getDoctrine()->getManager();
        $all_products = $em->getRepository('HotelBundle:Product')->findBy(array('forSelling'=>0), array('name'=>'ASC'));

        return $this->render('HotelBundle:Add:add_product.html.twig', array('products'=>$all_products));

    }


    /**
     * @Route("/employees", name="employees")
     */
    public function employeesAction()
    {

        $em = $this->getDoctrine()->getManager();
        $all_employees = $em->getRepository('HotelBundle:Employee')->findBy(array(), array('name'=>'ASC'));

        return $this->render('HotelBundle:Display:employees.html.twig', array('employees'=>$all_employees));

    }

    /**
     * @Route("/buyings", name="buyings")
     */
    public function buyingsAction()
    {

        $em = $this->getDoctrine()->getManager();
        $all_products = $em->getRepository('HotelBundle:Product')->findBy(array('forSelling'=>0), array('name'=>'ASC'));

        return $this->render('HotelBundle:Add:buying.html.twig', array('employees'=>$all_products));

    }

}
