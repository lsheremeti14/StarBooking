<?php

namespace HotelBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;

use HotelBundle\Entity\User;
use HotelBundle\Entity\UserRole;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;

use Doctrine\DBAL\Statement;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\Filesystem\Filesystem;
use Symfony\Component\Filesystem\Exception\IOExceptionInterface;
use Symfony\Component\Validator\Constraints\DateTime;

class UpdateController extends Controller
{

    /**
     *
     * @param Request $request
     * @Route("/update-employee", name="update_employee")
     */
    public function updateEmployeeAction(){

        $em = $this->getDoctrine()->getManager();
        $request = $this->getRequest();

            if($request->isXmlHttpRequest()) {


            $id=$request->get('e_id');
            $name = $request->get('e_name');
            $surname = $request->get('e_surname');
            $position = $request->get('e_position');
            $address = $request->get('e_address');
            $cel = $request->get('e_cel');
            $salary = $request->get('e_salary');
            $date2 = $request->get('e_date');
            $date=date('Y-m-d',strtotime($date2));

            $sql = "UPDATE `employee` SET `name`='$name',`surname`='$surname',`position`='$position', `address`='$address',`cel`='$cel',`salary`='$salary',`starting_date`='$date' WHERE `id`=$id";
            $stmt = $em->getConnection()->prepare($sql);
            $stmt->execute();

                $message = array();
                $message[0] = "OK";
                $response = new Response();
                $data = json_encode($message);
                $response->headers->set('Content-Type', 'application/json');
                $response->setContent($data);
                return $response;
            } else {
                return new Response('no ajax');
            }
    }

    /**
     *
     * @param Request $request
     * @Route("/update-room", name="update_room")
     */
    public function updateRoomAction(){

        $em = $this->getDoctrine()->getManager();
        $request = $this->getRequest();

        if($request->isXmlHttpRequest()) {


            $id=$request->get('id');
            $code = $request->get('code');
            $description = $request->get('description');
            $beds = $request->get('beds');
            $price = $request->get('price');

            $sql = "UPDATE `room` SET `code`='$code',`description`='$description',`beds`='$beds', `price`='$price' WHERE `id`=$id";
            $stmt = $em->getConnection()->prepare($sql);
            $stmt->execute();

            $message = array();
            $message[0] = "OK";
            $response = new Response();
            $data = json_encode($message);
            $response->headers->set('Content-Type', 'application/json');
            $response->setContent($data);
            return $response;
        } else {
            return new Response('no ajax');
        }
    }

}
