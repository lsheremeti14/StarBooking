<?php

namespace HotelBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class HotelBundle extends Bundle
{
}
